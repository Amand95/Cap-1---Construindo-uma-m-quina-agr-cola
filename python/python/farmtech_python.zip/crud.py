from database import conectar

def inserir_leitura(fosforo, potassio, ph, umidade):
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute('''
        INSERT INTO leituras (fosforo, potassio, ph, umidade)
        VALUES (?, ?, ?, ?)
    ''', (fosforo, potassio, ph, umidade))

    conexao.commit()
    conexao.close()

def listar_leituras():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute('SELECT * FROM leituras')
    resultados = cursor.fetchall()

    conexao.close()
    return resultados
