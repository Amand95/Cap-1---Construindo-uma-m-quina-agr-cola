# 📊 Módulo de Banco de Dados e CRUD - FarmTech Solutions

Este módulo Python é responsável por armazenar, recuperar e simular leituras de sensores da máquina agrícola.

## 📁 Estrutura dos Arquivos

- `database.py`: Criação da conexão com o SQLite e das tabelas.
- `crud.py`: Funções de inserir e listar os dados das leituras.
- `main.py`: Simulação de uma leitura e execução das operações CRUD.
- `sensores.db`: Arquivo gerado automaticamente após a primeira execução, contendo os dados persistidos.

## ▶️ Como Executar

1. Certifique-se de estar no diretório `python/python`.
2. Execute o script principal:

```bash
python main.py
```

3. Isso irá:
   - Criar o banco de dados e a tabela (se ainda não existirem).
   - Simular uma leitura e inseri-la no banco.
   - Listar todas as leituras armazenadas.

## 🧱 Requisitos

- Python 3.x
- SQLite (já incluso nas distribuições padrão do Python)

## 📌 Observações

- Os valores de leitura são simulados. Para integrações reais com sensores, substitua a função `simular_leitura()` por valores capturados do ESP32.
