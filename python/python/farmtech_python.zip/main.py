from database import criar_tabelas
from crud import inserir_leitura, listar_leituras

def simular_leitura():
    # Exemplo de valores simulados
    fosforo = 20.5
    potassio = 35.2
    ph = 6.8
    umidade = 45.0
    return fosforo, potassio, ph, umidade

if __name__ == "__main__":
    criar_tabelas()
    fosforo, potassio, ph, umidade = simular_leitura()
    inserir_leitura(fosforo, potassio, ph, umidade)

    leituras = listar_leituras()
    for leitura in leituras:
        print(leitura)
